Projeto em Visual Studio 2022 com C#, utilizando como exemplo nas aulas de Desenvolvimento de Aplicações Desktop para mostrar como trabalhar com Banco de Dados em C#.
